function goToPage(filename){
   window.location.href = filename+".html";
 
}