function goToPage(filename){
    window.location.href = filename+".html";
}

function goToSection(sectionId){
    window.location.hash="#sectionId";
}